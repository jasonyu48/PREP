import ollama
import math
import sys
import json
import pandas as pd

class ChatAssistant:
    def __init__(self, LLM, system_message=None):
        self.LLM = LLM
        self.system_message = system_message
        self.chat_messages = []

    def create_message(self, message, role):
        return {
            'role': role,
            'content': message
        }

    def chat(self):

        # Set default options
        options = {'temperature': temperature, 'num_predict': 1024}

        # Modify options if the model is 'phi3:medium'
        # Otherwise phi3 is unstable
        if self.LLM == 'phi3:medium':
            options['num_ctx'] = 8000

        ollama_response = ollama.chat(model=self.LLM, stream=False, messages=self.chat_messages, options = options)
        assistant_message = ollama_response['message']['content']
        print(assistant_message)
        self.chat_messages.append(self.create_message(assistant_message, 'assistant'))
        return assistant_message

    def ask(self, message):
        if not self.chat_messages and self.system_message is not None:
            self.chat_messages.append(self.create_message(self.system_message, 'system'))
        self.chat_messages.append(self.create_message(message, 'user'))
        print(f'\n\n--{message}--\n\n')
        assistant_message = self.chat()
        return assistant_message
    
    def ask_CoT(self, question, trigger_prompt = "Let's think step by step."):
        # Set default options
        options = {'temperature': temperature, 'num_predict': 1024}

        # Modify options if the model is 'phi3:medium'
        # Otherwise phi3 is unstable
        if self.LLM == 'phi3:medium':
            options['num_ctx'] = 8000

        prompt = self.add_template_CoT(question, trigger_prompt)
        assistant_message = ollama.generate(model=self.LLM, prompt = prompt, options = options, raw=True)['response']

        print(prompt + assistant_message)

        return assistant_message

    def is_correct(self, assistant_message, correct_answer):
        assistant_message = assistant_message.lower()
        answer_yes = any(keyword in assistant_message for keyword in ['answer is likely yes', "would be: yes", "would be \"yes", "would be 'yes", 'answer: yes', 'answer is yes', 'answer is: yes', "answer is **yes", "answer is: **yes", "answer is:\n\nyes", "would be yes", "would be **yes", 'would be "yes', 'would be:\nyes', "answer is 'yes", "answer is \"yes", "answer is:\nyes", "answer is: \nyes", 'answer is clearly **yes', 'answer is definitely yes', 'answer is definitely **yes', 'answer is therefore yes', "answer is definitely 'yes", "answer is clearly 'yes", 'answer is clearly yes', 'answer is a definite yes', "answer is a definite 'yes", "answer is most definitely yes", 'answer is a resounding yes', "answer is a resounding 'yes", "answer is definitively yes", "answer is a definite \"yes"]) or assistant_message[:4] == 'yes,'
        answer_no = any(keyword in assistant_message for keyword in ['answer is likely no', "would be: no", "would be \"no", "would be 'no", 'answer: no', 'answer is no', 'answer is: no', "answer is **no", "answer is: **no", "answer is:\n\nno", "would be yes", "would be **no", 'would be "no', 'would be:\nno', "answer is 'no", "answer is \"no", "answer is:\nno", "answer is: \nno", 'answer is clearly **no', 'answer is definitely no', 'answer is definitely **no', 'answer is therefore no', "answer is definitely 'no", "answer is clearly 'no", 'answer is clearly no', 'answer is a definite no', "answer is a definite 'no", "answer is most definitely no", 'answer is a resounding no', "answer is a resounding 'no", "answer is definitively no", "answer is a definite \"no"]) or assistant_message[:3] == 'no,'

        if answer_yes and answer_no:
            return 0 # wrong
        elif (correct_answer and answer_yes) or ((not correct_answer) and answer_no):
            return 1  # Correct
        elif answer_yes or answer_no:
            return 0  # Wrong
        else:
            return 2  # Unable to determine

    def direct_test_baseline(self, dataset):
        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} direct baseline {self.LLM}")
        num_questions = len(dataset)

        for i, item in enumerate(dataset):
            self.__init__(self.LLM, self.system_message) #new chat
            question = (self.prepare_question(item) + "Clearly indicate the answer by saying 'my answer is yes' or 'my answer is no' at the end of your response.")
            assistant_message = self.ask(question)
            evaluation = self.is_correct(assistant_message, item['answer'])

            if evaluation == 1:
                num_correct += 1
                print("\n\ncorrect")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(question)
                print("\n\nnot even wrong")
            else:
                print("\n\nwrong")

        accuracy = num_correct / num_questions
        print(f"\n\nnum_tests: {num_questions}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy * (1 - accuracy) / num_questions)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for question in cannot_tell_answer:
                print(question)
        return accuracy

    def cot_exp6(self, dataset):
        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp6: CoT baseline {self.LLM}")
        num_questions = len(dataset)

        for i, item in enumerate(dataset):
            self.__init__(self.LLM, self.system_message) #new chat
            question = self.prepare_cot_question(item)
            assistant_message = self.ask_CoT(question)
            evaluation = self.is_correct(assistant_message, item['answer'])

            if evaluation == 1:
                num_correct += 1
                print("\n\ncorrect")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(question)
                print("\n\nnot even wrong")
            else:
                print("\n\nwrong")

        accuracy = num_correct / num_questions
        print(f"\n\nnum_tests: {num_questions}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy * (1 - accuracy) / num_questions)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for question in cannot_tell_answer:
                print(question)
        return accuracy

    def PS_exp61(self, dataset):
        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp61: PS {self.LLM}")
        num_questions = len(dataset)

        for i, item in enumerate(dataset):
            self.__init__(self.LLM, self.system_message) #new chat
            question = self.prepare_cot_question(item)
            assistant_message = self.ask_CoT(question, "Let's first understand the problem and devise a plan to solve the problem. Then, let's carry out the plan and solve the problem step by step.")
            evaluation = self.is_correct(assistant_message, item['answer'])

            if evaluation == 1:
                num_correct += 1
                print("\n\ncorrect")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(question)
                print("\n\nnot even wrong")
            else:
                print("\n\nwrong")

        accuracy = num_correct / num_questions
        print(f"\n\nnum_tests: {num_questions}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy * (1 - accuracy) / num_questions)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for question in cannot_tell_answer:
                print(question)
        return accuracy

    def two_prompt_indep_exp44(self, dataset):
        prompts1 = []
        prompts2 = []
        for item in dataset:
            prompts1.append(self.prepare_44_prompt1(item))
            prompts2.append(self.prepare_44_prompt2())
        num_tests = len(prompts1)

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp4.4: two prompt user independent {self.LLM}")

        for i in range(num_tests):
            self.__init__(self.LLM, self.system_message) #new chat
            self.ask(prompts1[i])
            assistant_message = self.ask(prompts2[i])
            evaluation = self.is_correct(assistant_message, dataset[i]['answer'])

            if evaluation == 1:
                num_correct += 1
                print("\n\ncorrect")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(prompts1[i])
                print("\n\nnot even wrong")
            else:
                print("\n\nwrong")

        accuracy = num_correct / num_tests
        print(f"\n\nnum_tests: {num_tests}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy * (1 - accuracy) / num_tests)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for question in cannot_tell_answer:
                print(question)
        return accuracy

    def selfrag_indep_exp52(self, dataset):
        prompts1 = []
        prompts2 = []
        for item in dataset:
            prompts1.append(self.prepare_52_prompt1(item))
            prompts2.append(self.prepare_52_prompt2(item))
        num_tests = len(prompts1)

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp52 {self.LLM}")

        for i in range(num_tests):
            self.__init__(self.LLM, self.system_message) #new chat
            assistant_message = self.ask(prompts1[i])

            self.__init__(self.LLM, self.system_message) #new chat
            q = (f"Here are some facts that are relevant to the question I will ask you:\n"
                 f"{assistant_message.strip()}\n"
                 f"\n"
                 f"Here is the question:\n"
                 f"{prompts2[i]}")
            assistant_message = self.ask(q)
            evaluation = self.is_correct(assistant_message, dataset[i]['answer'])

            if evaluation == 1:
                num_correct += 1
                print("\n\ncorrect")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(prompts2[i])
                print("\n\nnot even wrong")
            else:
                print("\n\nwrong")

        accuracy = num_correct / num_tests
        print(f"\n\nnum_tests: {num_tests}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy * (1 - accuracy) / num_tests)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for question in cannot_tell_answer:
                print(question)
        return accuracy
    
    def copy53(self, dataset):
        prompts1 = []
        prompts2 = []
        for item in dataset:
            prompts1.append(self.prepare_52_prompt1(item))
            prompts2.append(self.prepare_53_prompt2())
        num_tests = len(prompts1)

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp53 {self.LLM}")

        for i in range(num_tests):
            self.__init__(self.LLM, self.system_message) #new chat
            assistant_message = self.ask(prompts1[i])

            q = (f"Here are some facts that are relevant to the question:\n"
                 f"{assistant_message.strip()}\n"
                 f"\n"
                 f"{prompts2[i]}")
            assistant_message = self.ask(q)
            evaluation = self.is_correct(assistant_message, dataset[i]['answer'])

            if evaluation == 1:
                num_correct += 1
                print("\n\ncorrect")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(prompts2[i])
                print("\n\nnot even wrong")
            else:
                print("\n\nwrong")

        accuracy = num_correct / num_tests
        print(f"\n\nnum_tests: {num_tests}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy * (1 - accuracy) / num_tests)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for question in cannot_tell_answer:
                print(question)
        return accuracy

    def one_prompt_indep_exp76(self, dataset):
        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp76: one prompt user independent {self.LLM}")
        num_questions = len(dataset)

        for i, item in enumerate(dataset):
            self.__init__(self.LLM, self.system_message) #new chat
            question = self.prepare_76_prompt(item)
            assistant_message = self.ask(question)
            evaluation = self.is_correct(assistant_message, item['answer'])

            if evaluation == 1:
                num_correct += 1
                print("\n\ncorrect")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(question)
                print("\n\nnot even wrong")
            else:
                print("\n\nwrong")

        accuracy = num_correct / num_questions
        print(f"\n\nnum_tests: {num_questions}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy * (1 - accuracy) / num_questions)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for question in cannot_tell_answer:
                print(question)
        return accuracy

    def prepare_question(self, item):
        return f"{item['question']}\n"

    def prepare_cot_question(self, item):
        question_text = self.prepare_question(item)
        return (f"{question_text}"
                f"Clearly indicate the answer by saying 'my answer is yes' or 'my answer is no' at the end of your response.")
    
    def add_template_CoT(self, question, trigger_prompt):
        if self.LLM == "phi3:medium":
            prompt = (f"<|user|>\n"
                        f"{question}<|end|>\n"
                        f"<|assistant|>\n"
                        f"{trigger_prompt}")
        else:
            prompt = (f"<|START_OF_TURN_TOKEN|><|USER_TOKEN|>{question}<|END_OF_TURN_TOKEN|>\n"
                      f"<|START_OF_TURN_TOKEN|><|CHATBOT_TOKEN|>{trigger_prompt}")
        # else:
        #     prompt = f"<|START_OF_TURN_TOKEN|><|USER_TOKEN|>{question}<|END_OF_TURN_TOKEN|><|START_OF_TURN_TOKEN|><|CHATBOT_TOKEN|>{trigger_prompt}"
        return prompt

    def prepare_44_prompt1(self, item):
        question_text = self.prepare_question(item)
        return (f"Consider the following question:\n"
                f"{question_text}"
                f"Please list specific facts that seem most relevant to answering the question. Do not answer the question, and do not include anything other than the list in your response.")

    def prepare_44_prompt2(self):
        return "Consider the question based on common sense and the information. Clearly indicate the answer by saying 'my answer is yes' or 'my answer is no' at the end of your response."

    def prepare_52_prompt1(self, item):
        question_text = self.prepare_question(item)
        return (f"Consider the following question:\n"
                f"{question_text}"
                f"Please list specific facts that seem most relevant to answering the question. Do not answer the question, and do not include anything other than the list in your response.")

    def prepare_52_prompt2(self, item):
        question_text = self.prepare_question(item)
        return (f"{question_text}"
                f"Consider the question based on common sense and the information. Clearly indicate the answer by saying 'my answer is yes' or 'my answer is no' at the end of your response.")

    def prepare_53_prompt2(self):
        return "Consider the question based on common sense and the information. Clearly indicate the answer by saying 'my answer is yes' or 'my answer is no' at the end of your response."

    def prepare_76_prompt(self, item):
        question_text = self.prepare_question(item)
        return (f"{question_text}"
                f"Before giving your answer, please first list specific facts that seem most relevant to answering the question.\n"
                f"Clearly indicate the answer by saying 'my answer is yes' or 'my answer is no' at the end of your response.")

temperature = 0.0

def experiment():
    system_message = None

    LMs = ['phi3:medium']
    # LMs = ['aya:35b', 'command-r']

    # Load StrategyQA dataset
    with open('/home/jyu48/PREP/StrategyQA/data/strategyqa_train_filtered.json', 'r', encoding='utf-8') as file:
        data = json.load(file)
    df = pd.DataFrame(data)
    shuffled_df = df.sample(frac=1).reset_index(drop=True)
    test_data = shuffled_df.head(500).to_dict(orient='records')

    direct_acc = []
    cot_acc = []
    two_prompt_indep_acc4 = []
    one_prompt_indep_acc6 = []
    acc52 = []
    acc53 = []
    PS_acc = []

    print('PS')
    for LM in LMs:
        
        original_stdout = sys.stdout
        sys.stdout = open(f"/home/jyu48/PREP/StrategyQA/i/t{temperature} PS {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

        assistant = ChatAssistant(LM, system_message)
        acc = assistant.PS_exp61(test_data)
        PS_acc.append(acc)

        sys.stdout.close()
        sys.stdout = original_stdout  # Reset the standard output to its original value
    print(PS_acc)

    print('exp53')
    for LM in LMs:
        original_stdout = sys.stdout
        sys.stdout = open(f"/home/jyu48/PREP/StrategyQA/i/t{temperature} exp53 copy {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

        assistant = ChatAssistant(LM, system_message)
        acc = assistant.copy53(test_data)
        acc53.append(acc)

        sys.stdout.close()
        sys.stdout = original_stdout  # Reset the standard output to its original value
    print(acc53)

    print('exp52')
    for LM in LMs:
        original_stdout = sys.stdout
        sys.stdout = open(f"/home/jyu48/PREP/StrategyQA/i/t{temperature} exp52 indep {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

        assistant = ChatAssistant(LM, system_message)
        acc = assistant.selfrag_indep_exp52(test_data)
        acc52.append(acc)

        sys.stdout.close()
        sys.stdout = original_stdout  # Reset the standard output to its original value
    print(acc52)

    print('direct')
    for LM in LMs:
        original_stdout = sys.stdout
        sys.stdout = open(f"/home/jyu48/PREP/StrategyQA/i/t{temperature} direct {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

        assistant = ChatAssistant(LM, system_message)
        acc = assistant.direct_test_baseline(test_data)
        direct_acc.append(acc)

        sys.stdout.close()
        sys.stdout = original_stdout  # Reset the standard output to its original value
    print(direct_acc)

    print('CoT')
    for LM in LMs:
        original_stdout = sys.stdout
        sys.stdout = open(f"/home/jyu48/PREP/StrategyQA/i/t{temperature} CoT {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

        assistant = ChatAssistant(LM, system_message)
        acc = assistant.cot_exp6(test_data)
        cot_acc.append(acc)

        sys.stdout.close()
        sys.stdout = original_stdout  # Reset the standard output to its original value
    print(cot_acc)
    print()
    print()

    print('exp4indep4')
    for LM in LMs:
        original_stdout = sys.stdout
        sys.stdout = open(f"/home/jyu48/PREP/StrategyQA/i/t{temperature} exp4indep4 {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

        assistant = ChatAssistant(LM, system_message)
        acc = assistant.two_prompt_indep_exp44(test_data)
        two_prompt_indep_acc4.append(acc)

        sys.stdout.close()
        sys.stdout = original_stdout  # Reset the standard output to its original value
    print(two_prompt_indep_acc4)

    print('exp7indep6')
    for LM in LMs:
        original_stdout = sys.stdout
        sys.stdout = open(f"/home/jyu48/PREP/StrategyQA/i/t{temperature} exp7indep6 {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

        assistant = ChatAssistant(LM, system_message)
        acc = assistant.one_prompt_indep_exp76(test_data)
        one_prompt_indep_acc6.append(acc)

        sys.stdout.close()
        sys.stdout = original_stdout  # Reset the standard output to its original value
    print(one_prompt_indep_acc6)

experiment()
