import ollama

def generate_cot_response_with_template():
    # Define the prompt using the template structure
    prompt = """<|user|>
If you are prone to postpone work what will you have to do in order to finish on time?
a) eat
b) hasten
c) antedate
d) bring forward
e) advance
Clearly indicate the answer by saying 'my answer is a)', 'my answer is b)', 'my answer is c)', 'my answer is d)', or 'my answer is e)' at the end of your response. You can only select one option.<|end|>
<|assistant|>
"""
    
    # Send the prompt to the model using ollama.generate
    response = ollama.generate(model="phi3:medium", prompt=prompt,options={'temperature': 0.0},raw=True)

    print(response['response'])

# Run the function
generate_cot_response_with_template()


def chat_cot_response():
    
    # Define the user message with the same content as the original prompt
    user_message = """If you are prone to postpone work what will you have to do in order to finish on time?
a) eat
b) hasten
c) antedate
d) bring forward
e) advance
Clearly indicate the answer by saying 'my answer is a)', 'my answer is b)', 'my answer is c)', 'my answer is d)', or 'my answer is e)' at the end of your response. You can only select one option."""
    
    # Create the chat history for the conversation
    messages = [
        {"role": "user", "content": user_message}
    ]
    
    # Send the messages to the model using ollama.chat
    response = ollama.chat(model="phi3:medium", messages=messages, options={'temperature': 0.0})

    # Print the response
    print(response['message']['content'])

# Run the function
chat_cot_response()

