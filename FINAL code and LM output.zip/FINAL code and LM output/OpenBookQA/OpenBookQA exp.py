import ollama
import math
import sys
from datasets import load_dataset

class ChatAssistant:
    def __init__(self, LLM, system_message = None):
        self.LLM = LLM
        self.system_message = system_message
        self.chat_messages = []

    def create_message(self, message, role):
        return {
            'role': role,
            'content': message
        }

    def chat(self):
        # Set default options
        options = {'temperature': temperature}

        # Modify options if the model is 'phi3:medium'
        # Otherwise phi3 is unstable
        # if self.LLM == 'phi3:medium':
        #     options['num_ctx'] = 40000
        # Calling the ollama API to get the assistant response
        ollama_response = ollama.chat(model=self.LLM, stream=False, messages=self.chat_messages, options=options)

        assistant_message = ollama_response['message']['content']
        print(assistant_message)

        # Adding the finalized assistant message to the chat log
        self.chat_messages.append(self.create_message(assistant_message, 'assistant'))

        return assistant_message

    def ask(self, message):
        if not self.chat_messages and self.system_message is not None:
            self.chat_messages.append(self.create_message(self.system_message, 'system'))
        self.chat_messages.append(self.create_message(message, 'user'))
        print(f'\n\n--{message}--\n\n')
        assistant_message = self.chat()

        return assistant_message
    
    def ask_CoT(self, question, trigger_prompt = "Let's think step by step."):
        # Set default options
        options = {'temperature': temperature}

        # Modify options if the model is 'phi3:medium'
        # Otherwise phi3 is unstable
        # if self.LLM == 'phi3:medium':
        #     options['num_ctx'] = 40000

        prompt = self.add_template_CoT(question, trigger_prompt)
        assistant_message = ollama.generate(model=self.LLM, prompt=prompt, options=options, raw=True)['response']

        print(prompt + assistant_message)

        return assistant_message

    def is_correct(self, assistant_message, correct_answer):
        assistant_message = assistant_message.lower()
        # Check conditions for each option
        contains_a = any(keyword in assistant_message for keyword in ['answer is likely a', "would be: a", "would be \"a", "would be 'a", "answer is \"a", 'answer: a', "answer is 'a", 'answer is:\n\na', 'answer is clearly **a', 'answer is:\na', 'answer is: \na', 'answer is a', 'answer is: a', 'answer is definitely a', 'answer is definitely **a', 'answer is **a', 'answer is therefore a', "answer is definitely 'a", "answer is clearly 'a", 'answer is clearly a', 'answer is: **a', 'would be "a', 'would be:\na', 'would be a)', 'answer is (a', 'answer is a definite a', "answer is a definite 'a", "answer is most definitely a", 'answer is a resounding a', "answer is a resounding 'a", "answer is definitively a", "answer is a definite \"a"])
        contains_b = any(keyword in assistant_message for keyword in ['answer is likely b', "would be: b", "would be \"b", "would be 'b", "answer is \"b", 'answer: b', "answer is 'b", 'answer is:\n\nb', 'answer is clearly **b', 'answer is:\nb', 'answer is: \nb', 'answer is b', 'answer is: b', 'answer is definitely b', 'answer is definitely **b', 'answer is **b', 'answer is therefore b', "answer is definitely 'b", "answer is clearly 'b", 'answer is clearly b', 'answer is: **b', 'would be "b', 'would be:\nb', 'would be b)', 'answer is (b', 'answer is a definite b', "answer is a definite 'b", "answer is most definitely b", 'answer is a resounding b', "answer is a resounding 'b", "answer is definitively b", "answer is a definite \"b"])
        contains_c = any(keyword in assistant_message for keyword in ['answer is likely c', "would be: c", "would be \"c", "would be 'c", "answer is \"c", 'answer: c', "answer is 'c", 'answer is:\n\nc', 'answer is clearly **c', 'answer is:\nc', 'answer is: \nc', 'answer is c', 'answer is: c', 'answer is definitely c', 'answer is definitely **c', 'answer is **c', 'answer is therefore c', "answer is definitely 'c", "answer is clearly 'c", 'answer is clearly c', 'answer is: **c', 'would be "c', 'would be:\nc', 'would be c)', 'answer is (c', 'answer is a definite c', "answer is a definite 'c", "answer is most definitely c", 'answer is a resounding c', "answer is a resounding 'c", "answer is definitively c", "answer is a definite \"c"])
        contains_d = any(keyword in assistant_message for keyword in ['answer is likely d', "would be: d", "would be \"d", "would be 'd", "answer is \"d", 'answer: d', "answer is 'd", 'answer is:\n\nd', 'answer is clearly **d', 'answer is:\nd', 'answer is: \nd', 'answer is d', 'answer is: d', 'answer is definitely d', 'answer is definitely **d', 'answer is **d', 'answer is therefore d', "answer is definitely 'd", "answer is clearly 'd", 'answer is clearly d', 'answer is: **d', 'would be "d', 'would be:\nd', 'would be d)', 'answer is (d', 'answer is a definite d', "answer is a definite 'd", "answer is most definitely d", 'answer is a resounding d', "answer is a resounding 'd", "answer is definitively d", "answer is a definite \"d"])

        contains_answer = {
            'A': contains_a or (assistant_message[:2]=='a)' and 'b)' not in assistant_message and 'c)' not in assistant_message and 'd)' not in assistant_message),
            'B': contains_b or (assistant_message[:2]=='b)' and 'a)' not in assistant_message and 'c)' not in assistant_message and 'd)' not in assistant_message),
            'C': contains_c or (assistant_message[:2]=='c)' and 'a)' not in assistant_message and 'b)' not in assistant_message and 'd)' not in assistant_message),
            'D': contains_d or (assistant_message[:2]=='d)' and 'a)' not in assistant_message and 'b)' not in assistant_message and 'c)' not in assistant_message),
        }

        # Check if more than one answer is present
        if sum(contains_answer.values()) > 1:
            return 0  # Wrong
        elif contains_answer[correct_answer]:
            return 1  # Correct
        elif any(contains_answer.values()):
            return 0  # Wrong
        else:
            return 2  # Unable to determine


    def direct_test_baseline(self, dataset):
        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} direct baseline {self.LLM}")
        num_questions = len(dataset)

        for i, item in enumerate(dataset):
            self.__init__(self.LLM, self.system_message) #new chat
            question = (self.prepare_question(item) + "Clearly indicate the answer by saying 'my answer is a)', 'my answer is b)', 'my answer is c)', or 'my answer is d)' at the end of your response. You can only select one option.")
            assistant_message = self.ask(question)
            evaluation = self.is_correct(assistant_message, item['answerKey'])

            if evaluation == 1:
                num_correct += 1
                print("\n\ncorrect")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(question)
                print("\n\nnot even wrong")
            else:
                print("\n\nwrong")

        accuracy = num_correct / num_questions
        print(f"\n\nnum_tests: {num_questions}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy * (1 - accuracy) / num_questions)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for question in cannot_tell_answer:
                print(question)
        return accuracy

    def cot_exp6(self, dataset):
        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp6: CoT baseline {self.LLM}")
        num_questions = len(dataset)

        for i, item in enumerate(dataset):
            self.__init__(self.LLM, self.system_message) #new chat
            question = self.prepare_cot_question(item)
            assistant_message = self.ask_CoT(question)
            evaluation = self.is_correct(assistant_message, item['answerKey'])

            if evaluation == 1:
                num_correct += 1
                print("\n\ncorrect")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(question)
                print("\n\nnot even wrong")
            else:
                print("\n\nwrong")

        accuracy = num_correct / num_questions
        print(f"\n\nnum_tests: {num_questions}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy * (1 - accuracy) / num_questions)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for question in cannot_tell_answer:
                print(question)
        return accuracy
    
    def PS_exp61(self, dataset):
        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp61: PS {self.LLM}")
        num_questions = len(dataset)

        for i, item in enumerate(dataset):
            self.__init__(self.LLM, self.system_message) #new chat
            question = self.prepare_cot_question(item)
            assistant_message = self.ask_CoT(question, "Let's first understand the problem and devise a plan to solve the problem. Then, let's carry out the plan and solve the problem step by step.")
            evaluation = self.is_correct(assistant_message, item['answerKey'])

            if evaluation == 1:
                num_correct += 1
                print("\n\ncorrect")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(question)
                print("\n\nnot even wrong")
            else:
                print("\n\nwrong")

        accuracy = num_correct / num_questions
        print(f"\n\nnum_tests: {num_questions}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy * (1 - accuracy) / num_questions)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for question in cannot_tell_answer:
                print(question)
        return accuracy

    def two_prompt_indep_exp44(self, dataset):
        prompts1 = []
        prompts2 = []
        for item in dataset:
            prompts1.append(self.prepare_44_prompt1(item))
            prompts2.append(self.prepare_44_prompt2())
        num_tests = len(prompts1)

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp4.4: two prompt user independent {self.LLM}")

        for i in range(num_tests):
            self.__init__(self.LLM, self.system_message) #new chat
            self.ask(prompts1[i])
            assistant_message = self.ask(prompts2[i])
            evaluation = self.is_correct(assistant_message, dataset[i]['answerKey'])

            if evaluation == 1:
                num_correct += 1
                print("\n\ncorrect")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(prompts1[i])
                print("\n\nnot even wrong")
            else:
                print("\n\nwrong")

        accuracy = num_correct / num_tests
        print(f"\n\nnum_tests: {num_tests}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy * (1 - accuracy) / num_tests)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for question in cannot_tell_answer:
                print(question)
        return accuracy
    
    def selfrag_indep_exp52(self, dataset):
        prompts1 = []
        prompts2 = []
        for item in dataset:
            prompts1.append(self.prepare_52_prompt1(item))
            prompts2.append(self.prepare_52_prompt2(item))
        num_tests = len(prompts1)

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp52 {self.LLM}")

        for i in range(num_tests):
            self.__init__(self.LLM, self.system_message) #new chat
            assistant_message = self.ask(prompts1[i])

            self.__init__(self.LLM, self.system_message) #new chat
            q = (f"Here are some facts that are relevant to the question I will ask you:\n"
                 f"{assistant_message.strip()}\n"
                 f"\n"
                 f"Here is the question:\n"
                 f"{prompts2[i]}")
            assistant_message = self.ask(q)
            evaluation = self.is_correct(assistant_message, dataset[i]['answerKey'])

            if evaluation == 1:
                num_correct += 1
                print("\n\ncorrect")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(prompts2[i])
                print("\n\nnot even wrong")
            else:
                print("\n\nwrong")

        accuracy = num_correct / num_tests
        print(f"\n\nnum_tests: {num_tests}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy * (1 - accuracy) / num_tests)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for question in cannot_tell_answer:
                print(question)
        return accuracy
    
    def copy53(self, dataset):
        prompts1 = []
        prompts2 = []
        for item in dataset:
            prompts1.append(self.prepare_52_prompt1(item))
            prompts2.append(self.prepare_53_prompt2())
        num_tests = len(prompts1)

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp53 {self.LLM}")

        for i in range(num_tests):
            self.__init__(self.LLM, self.system_message) #new chat
            assistant_message = self.ask(prompts1[i])

            q = (f"Here are some facts that are relevant to the question:\n"
                 f"{assistant_message.strip()}\n"
                 f"\n"
                 f"{prompts2[i]}")
            assistant_message = self.ask(q)
            evaluation = self.is_correct(assistant_message, dataset[i]['answerKey'])

            if evaluation == 1:
                num_correct += 1
                print("\n\ncorrect")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(prompts2[i])
                print("\n\nnot even wrong")
            else:
                print("\n\nwrong")

        accuracy = num_correct / num_tests
        print(f"\n\nnum_tests: {num_tests}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy * (1 - accuracy) / num_tests)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for question in cannot_tell_answer:
                print(question)
        return accuracy
    
    def one_prompt_indep_exp76(self, dataset):
        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp76: one prompt user independent {self.LLM}")
        num_questions = len(dataset)

        for i, item in enumerate(dataset):
            self.__init__(self.LLM, self.system_message) #new chat
            question = self.prepare_76_prompt(item)
            assistant_message = self.ask(question)
            evaluation = self.is_correct(assistant_message, item['answerKey'])

            if evaluation == 1:
                num_correct += 1
                print("\n\ncorrect")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(question)
                print("\n\nnot even wrong")
            else:
                print("\n\nwrong")

        accuracy = num_correct / num_questions
        print(f"\n\nnum_tests: {num_questions}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy * (1 - accuracy) / num_questions)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for question in cannot_tell_answer:
                print(question)
        return accuracy
    
    def prepare_question(self, item):
        question = item['question_stem']
        choices = item['choices']['text']
        question_text = f"{question}\n"
        for i, choice in enumerate(choices):
            question_text += f"{chr(97 + i)}) {choice}\n"
        return question_text

    def prepare_cot_question(self, item):
        question_text = self.prepare_question(item)
        return (f"{question_text}"
                f"Clearly indicate the answer by saying 'my answer is a)', 'my answer is b)', 'my answer is c)', or 'my answer is d)' at the end of your response. You can only select one option.")

    def add_template_CoT(self, question, trigger_prompt):
        if self.LLM == "phi3:medium":
            prompt = (f"<|user|>\n"
                        f"{question}<|end|>\n"
                        f"<|assistant|>\n"
                        f"{trigger_prompt}")
        else:# self.LLM == 'command-r:35b-v0.1-q3_K_M':
            prompt = (f"<BOS_TOKEN><|START_OF_TURN_TOKEN|><|USER_TOKEN|>{question}<|END_OF_TURN_TOKEN|>\n"
                      f"<|START_OF_TURN_TOKEN|><|CHATBOT_TOKEN|>{trigger_prompt}")
        # else:
        #     prompt = f"<BOS_TOKEN><|START_OF_TURN_TOKEN|><|USER_TOKEN|>{question}<|END_OF_TURN_TOKEN|><|START_OF_TURN_TOKEN|><|CHATBOT_TOKEN|>{trigger_prompt}"
        return prompt

    def prepare_44_prompt1(self, item):
        question_text = self.prepare_question(item)
        question = (f"Consider the following question:\n"
                    f"{question_text}"
                    f"Please list specific facts that seem most relevant to answering the question. Do not answer the question, and do not include anything other than the list in your response.")
        return question

    def prepare_44_prompt2(self):
        return "Consider the question based on common sense and the information. Clearly indicate the answer by saying 'my answer is a)', 'my answer is b)', 'my answer is c)', or 'my answer is d)' at the end of your response. You can only select one option."

    def prepare_52_prompt1(self, item):
        question_text = self.prepare_question(item)
        question = (f"Consider the following multiple-choice problem:\n"
                    f"{question_text}"
                    f"Please list specific facts that seem most relevant to answering the question. Do not answer the question, and do not include anything other than the list in your response.")
        return question
    
    def prepare_52_prompt2(self, item):
        question_text = self.prepare_question(item)
        question = (f"{question_text}"
                    f"Consider the question based on common sense and the information. Clearly indicate the answer by saying 'my answer is a)', 'my answer is b)', 'my answer is c)', or 'my answer is d)' at the end of your response. You can only select one option.")
        return question
    
    def prepare_53_prompt2(self):
        return "Consider the question based on common sense and the information. Clearly indicate the answer by saying 'my answer is a)', 'my answer is b)', 'my answer is c)', or 'my answer is d)' at the end of your response. You can only select one option."
    
    def prepare_76_prompt(self, item):
        question_text = self.prepare_question(item)
        question = (f"{question_text}"
                    f"Before giving your answer, please first list specific facts that seem most relevant to answering the question.\n"
                    f"Clearly indicate the answer by saying 'my answer is a)', 'my answer is b)', 'my answer is c)', or 'my answer is d)' at the end of your response. You can only select one option.")
        return question

temperature = 0.0

def experiment():
    system_message = None

    # LMs = ['aya:35b-23-q3_K_M']
    # LMs = ['phi3:medium', 'aya:35b-23-q3_K_M', 'command-r:35b-v0.1-q3_K_M']
    # LMs = ['aya:35b-23-q3_K_M', 'command-r:35b-v0.1-q3_K_M']
    LMs = ['command-r:35b-v0.1-q3_K_M']

    # Load the OpenBookQA dataset
    ds = load_dataset("openbookqa", "main")['validation']
    shuffled_ds = ds.shuffle(seed=42)
    test_data = shuffled_ds.select(range(200))
    

    direct_acc = []
    cot_acc = []
    PS_acc = []
    two_prompt_indep_acc4 = []
    one_prompt_indep_acc6 = []
    acc52 = []
    acc53 = []

    # print('exp53')
    # for LM in LMs:
        
    #     original_stdout = sys.stdout
    #     sys.stdout = open(f"i/t{temperature} exp53 copy {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

    #     assistant = ChatAssistant(LM, system_message)
    #     acc = assistant.copy53(test_data)
    #     acc53.append(acc)


    #     sys.stdout.close()
    #     sys.stdout = original_stdout  # Reset the standard output to its original value
    # print(acc53)

    # print('exp52')
    # for LM in LMs:
        
    #     original_stdout = sys.stdout
    #     sys.stdout = open(f"i/t{temperature} exp52 indep {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

    #     assistant = ChatAssistant(LM, system_message)
    #     acc = assistant.selfrag_indep_exp52(test_data)
    #     acc52.append(acc)


    #     sys.stdout.close()
    #     sys.stdout = original_stdout  # Reset the standard output to its original value
    # print(acc52)

    # print('direct')
    # for LM in LMs:
        
    #     original_stdout = sys.stdout
    #     sys.stdout = open(f"i/t{temperature} direct {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

    #     assistant = ChatAssistant(LM, system_message)
    #     acc = assistant.direct_test_baseline(test_data)
    #     direct_acc.append(acc)

    #     sys.stdout.close()
    #     sys.stdout = original_stdout  # Reset the standard output to its original value
    # print(direct_acc)

    print('CoT')
    for LM in LMs:
        
        original_stdout = sys.stdout
        sys.stdout = open(f"k/t{temperature} CoT {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

        assistant = ChatAssistant(LM, system_message)
        acc = assistant.cot_exp6(test_data)
        cot_acc.append(acc)

        sys.stdout.close()
        sys.stdout = original_stdout  # Reset the standard output to its original value
    print(cot_acc)
    print()
    print()

    print('PS')
    for LM in LMs:
        
        original_stdout = sys.stdout
        sys.stdout = open(f"k/t{temperature} PS {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

        assistant = ChatAssistant(LM, system_message)
        acc = assistant.PS_exp61(test_data)
        PS_acc.append(acc)

        sys.stdout.close()
        sys.stdout = original_stdout  # Reset the standard output to its original value
    print(PS_acc)
    print()
    print()

    # print('exp4indep4')
    # for LM in LMs:
        
    #     original_stdout = sys.stdout
    #     sys.stdout = open(f"i/t{temperature} exp4indep4 {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

    #     assistant = ChatAssistant(LM, system_message)
    #     acc = assistant.two_prompt_indep_exp44(test_data)
    #     two_prompt_indep_acc4.append(acc)

    #     sys.stdout.close()
    #     sys.stdout = original_stdout  # Reset the standard output to its original value
    # print(two_prompt_indep_acc4)

    # print('exp7indep6')
    # for LM in LMs:
        
    #     original_stdout = sys.stdout
    #     sys.stdout = open(f"i/t{temperature} exp7indep6 {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

    #     assistant = ChatAssistant(LM, system_message)
    #     acc = assistant.one_prompt_indep_exp76(test_data)
    #     one_prompt_indep_acc6.append(acc)

    #     sys.stdout.close()
    #     sys.stdout = original_stdout  # Reset the standard output to its original value
    # print(one_prompt_indep_acc6)



experiment()