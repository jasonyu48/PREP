import ollama
import math
import sys
import random



class ChatAssistant:
    def __init__(self, LLM, system_message = None):
        self.LLM = LLM
        self.system_message = system_message
        self.chat_messages = []

    def create_message(self, message, role):
        return {
            'role': role,
            'content': message
        }

    def chat(self):
        # Set default options
        options = {'temperature': temperature}

        # Modify options if the model is 'phi3:medium'
        # Otherwise phi3 is unstable
        if self.LLM == 'phi3:medium':
            options['num_ctx'] = 40000

        # Use the options in the ollama.chat call
        ollama_response = ollama.chat(
            model=self.LLM, 
            stream=False, 
            messages=self.chat_messages, 
            options=options
        )

        assistant_message = ollama_response['message']['content']
        print(assistant_message)

        # Adding the finalized assistant message to the chat log
        self.chat_messages.append(self.create_message(assistant_message, 'assistant'))

        return assistant_message

    def ask(self, message):
        if not self.chat_messages and self.system_message is not None:
            self.chat_messages.append(self.create_message(self.system_message, 'system'))
        self.chat_messages.append(self.create_message(message, 'user'))
        print(f'\n\n--{message}--\n\n')
        assistant_message = self.chat()

        return assistant_message
    
    def ask_CoT(self, question, trigger_prompt = "Let's think step by step."):
        # Set default options
        options = {'temperature': temperature}

        # Modify options if the model is 'phi3:medium'
        # Otherwise phi3 is unstable
        if self.LLM == 'phi3:medium':
            options['num_ctx'] = 40000

        prompt = self.add_template_CoT(question, trigger_prompt)
        assistant_message = ollama.generate(model=self.LLM, prompt=prompt, options=options, raw=True)['response']

        print(prompt + assistant_message)

        return assistant_message

    def is_correct(self, assistant_message, index, total_questions):
        # Get the last 30 characters of the string

        # Define patterns
        patterns_a = ['answer is likely a', "would be: a", "would be \"a", "would be 'a", "answer is \"a", 'answer is a', "answer is 'a", "answer is **a", "answer is: a", "answer is: **a", 
                    "would be \"a", 'would be a)', 'a)** is less likely', 'a** is less likely', 
                    'answer is (a', 'a) is less likely', 'answer is clearly a', "answer is clearly 'a",
                    "answer is clearly **a", 'answer is definitely a', "answer is definitely 'a",
                    "answer is definitely **a", 'answer: a', 'answer is therefore a', "answer is:\na", 'answer is a definite a', "answer is a definite 'a", "answer is most definitely a", 'answer is a resounding a', "answer is a resounding 'a", "answer is definitively a", "answer is a definite \"a"]

        patterns_b = ['answer is likely b', "would be: b", "would be \"b", "would be 'b", "answer is \"b", 'answer is b', "answer is 'b", "answer is **b", "answer is: b", "answer is: **b", 
                    "would be \"b", 'would be b)', 'b)** is less likely', 'b** is less likely', 
                    'answer is (b', 'b) is less likely', 'answer is clearly b', "answer is clearly 'b",
                    "answer is clearly **b", 'answer is definitely b', "answer is definitely 'b",
                    "answer is definitely **b", 'answer: b', 'answer is therefore b', "answer is:\nb", 'answer is a definite b', "answer is a definite 'b", "answer is most definitely b", 'answer is a resounding b', "answer is a resounding 'b", "answer is definitively b", "answer is a definite \"b"]

        patterns_neither = ['answer is neither', 'answer is: neither', 
                            'answer is both', 'answer is: both', 
                            'answer is a) and b)', 'answer is a and b']

        # Check conditions
        contains_a = any(pattern in assistant_message.lower() for pattern in patterns_a) or (assistant_message[:2] == 'a)' and 'b)' not in assistant_message)
        contains_b = any(pattern in assistant_message.lower() for pattern in patterns_b) or (assistant_message[:2] == 'b)' and 'a)' not in assistant_message)
        answers_neither = any(pattern in assistant_message.lower() for pattern in patterns_neither)

        if answers_neither:
            return 0
        if index < total_questions//2:
            if contains_b and not contains_a:
                return 1
            elif (contains_a and not contains_b) or (contains_a and contains_b):
                return 0
            else:
                return 2
        else:
            if not contains_b and contains_a:
                return 1
            elif (not contains_a and contains_b) or (contains_a and contains_b):
                return 0
            else:
                return 2

    def direct_test_baseline(self):
        triples = read_artifact_triples(triple_file_path)
        questions = []
        for triple in triples:
            questions.append(triple_to_question(triple))

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} direct baseline {self.LLM}")
        num_questions = len(questions)

        for i in range(num_questions):
            self.__init__(self.LLM, self.system_message) #new chat
            assistant_message = self.ask(questions[i])
            evaluation = self.is_correct(assistant_message,i,num_questions)

            if evaluation == 1:
                num_correct += 1
                print()
                print()
                print("correct")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(questions[i])
                print()
                print()
                print("not even wrong")
            else:
                print()
                print()
                print("wrong")

        accuracy = num_correct/num_questions
        print()
        print()
        print(f"num_tests: {num_questions}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy*(1-accuracy)/num_questions)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for i in cannot_tell_answer:
                print(i)
        return accuracy

    def cot_exp6(self):
        triples = read_artifact_triples(triple_file_path)
        questions = []
        for triple in triples:
            questions.append(triple_to_COT_question(triple))

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp6: CoT baseline {self.LLM}")
        num_questions = len(questions)

        for i in range(num_questions):
            self.__init__(self.LLM, self.system_message) #new chat
            assistant_message = self.ask_CoT(questions[i])
            evaluation = self.is_correct(assistant_message,i,num_questions)

            if evaluation == 1:
                num_correct += 1
                print()
                print()
                print("correct")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(questions[i])
                print()
                print()
                print("not even wrong")
            else:
                print()
                print()
                print("wrong")

        accuracy = num_correct/num_questions
        print()
        print()
        print(f"num_tests: {num_questions}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy*(1-accuracy)/num_questions)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for i in cannot_tell_answer:
                print(i)
        return accuracy
    
    def PS_exp61(self):
        triples = read_artifact_triples(triple_file_path)
        questions = []
        for triple in triples:
            questions.append(triple_to_COT_question(triple))

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp61: PS {self.LLM}")
        num_questions = len(questions)

        for i in range(num_questions):
            self.__init__(self.LLM, self.system_message) #new chat
            assistant_message = self.ask_CoT(questions[i], "Let's first understand the problem and devise a plan to solve the problem. Then, let's carry out the plan and solve the problem step by step.")
            evaluation = self.is_correct(assistant_message,i,num_questions)

            if evaluation == 1:
                num_correct += 1
                print()
                print()
                print("correct")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(questions[i])
                print()
                print()
                print("not even wrong")
            else:
                print()
                print()
                print("wrong")

        accuracy = num_correct/num_questions
        print()
        print()
        print(f"num_tests: {num_questions}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy*(1-accuracy)/num_questions)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for i in cannot_tell_answer:
                print(i)
        return accuracy

    def two_prompt_indep_exp44(self):
        triples = read_artifact_triples(triple_file_path)
        prompts1 = []
        prompts2 = []
        for triple in triples:
            prompts1.append(triple_to_44(triple))
            prompts2.append(triple_to_44_prompt2())
        num_tests = len(prompts1)

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp4.4: two prompt user independent {self.LLM}")

        for i in range(num_tests):
            self.__init__(self.LLM, self.system_message) #new chat
            self.ask(prompts1[i])
            assistant_message = self.ask(prompts2[i])
            evaluation = self.is_correct(assistant_message, i, num_tests)

            if evaluation == 1:
                num_correct += 1
                print()
                print()
                print("correct")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(triples[i])
                print()
                print()
                print("not even wrong")
            else:
                print()
                print()
                print("wrong")

        accuracy = num_correct/num_tests
        print()
        print()
        print(f"num_tests: {num_tests}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy*(1-accuracy)/num_tests)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for i in cannot_tell_answer:
                print(i)
        return accuracy

    def two_prompt_dep_exp4(self):
        triples = read_artifact_triples(triple_file_path)
        prompts1 = []
        prompts2 = []
        for triple in triples:
            prompts1.append(triple_to_4_list_parts_of(triple))
            prompts2.append(p2_4(triple))
        num_tests = len(prompts1)

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp4: two prompt user dependent {self.LLM}")

        for i in range(num_tests):
            self.__init__(self.LLM, self.system_message) #new chat
            self.ask(prompts1[i])
            assistant_message = self.ask(prompts2[i])
            evaluation = self.is_correct(assistant_message, i, num_tests)

            if evaluation == 1:
                num_correct += 1
                print()
                print()
                print("correct")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(triples[i])
                print()
                print()
                print("not even wrong")
            else:
                print()
                print()
                print("wrong")

        accuracy = num_correct/num_tests
        print()
        print()
        print(f"num_tests: {num_tests}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy*(1-accuracy)/num_tests)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for i in cannot_tell_answer:
                print(i)
        return accuracy
    
    def selfrag_dep_exp5(self):
        triples = read_artifact_triples(triple_file_path)
        prompts1 = []
        prompts2 = []
        for triple in triples:
            prompts1.append(triple_to_5_list_parts_of(triple))
            prompts2.append(triple_to_question_5(triple))
        num_tests = len(prompts1)

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp5: selfrag user dependent {self.LLM}")

        for i in range(num_tests):
            self.__init__(self.LLM, self.system_message) #new chat
            assistant_message = self.ask(prompts1[i])

            self.__init__(self.LLM, self.system_message) #new chat
            q = (f"Here are some facts that are relevant to the question I will ask you:\n"
                 f"{assistant_message.strip()}\n"
                 f"\n"
                 f"Here is the question:\n"
                 f"{prompts2[i]}")
            assistant_message = self.ask(q)
            evaluation = self.is_correct(assistant_message, i, num_tests)

            if evaluation == 1:
                num_correct += 1
                print()
                print()
                print("correct")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(triples[i])
                print()
                print()
                print("not even wrong")
            else:
                print()
                print()
                print("wrong")

        accuracy = num_correct/num_tests
        print()
        print()
        print(f"num_tests: {num_tests}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy*(1-accuracy)/num_tests)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for i in cannot_tell_answer:
                print(i)
        return accuracy
    
    def selfrag_indep_exp52(self):
        triples = read_artifact_triples(triple_file_path)
        prompts1 = []
        prompts4 = []
        for triple in triples:
            prompts1.append(p1_52(triple))
            prompts4.append(p2_52(triple))
        num_tests = len(prompts1)

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp52 {self.LLM}")

        for i in range(num_tests):
            self.__init__(self.LLM, self.system_message) #new chat
            assistant_message = self.ask(prompts1[i])

            self.__init__(self.LLM, self.system_message) #new chat
            q = (f"Here are some facts that are relevant to the question I will ask you:\n"
                 f"{assistant_message.strip()}\n"
                 f"\n"
                 f"Here is the question:\n"
                 f"{prompts4[i]}")
            assistant_message = self.ask(q)
            evaluation = self.is_correct(assistant_message, i, num_tests)

            if evaluation == 1:
                num_correct += 1
                print()
                print()
                print("correct")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(triples[i])
                print()
                print()
                print("not even wrong")
            else:
                print()
                print()
                print("wrong")

        accuracy = num_correct/num_tests
        print()
        print()
        print(f"num_tests: {num_tests}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy*(1-accuracy)/num_tests)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for i in cannot_tell_answer:
                print(i)
        return accuracy
    
    def copy53(self):
        triples = read_artifact_triples(triple_file_path)
        prompts1 = []
        prompts4 = []
        for triple in triples:
            prompts1.append(p1_52(triple))
            prompts4.append(prepare_53_prompt2())
        num_tests = len(prompts1)

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp53 {self.LLM}")

        for i in range(num_tests):
            self.__init__(self.LLM, self.system_message) #new chat
            assistant_message = self.ask(prompts1[i])

            q = (f"Here are some facts that are relevant to the question:\n"
                 f"{assistant_message.strip()}\n"
                 f"\n"
                 f"{prompts4[i]}")
            assistant_message = self.ask(q)
            evaluation = self.is_correct(assistant_message, i, num_tests)

            if evaluation == 1:
                num_correct += 1
                print()
                print()
                print("correct")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(triples[i])
                print()
                print()
                print("not even wrong")
            else:
                print()
                print()
                print("wrong")

        accuracy = num_correct/num_tests
        print()
        print()
        print(f"num_tests: {num_tests}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy*(1-accuracy)/num_tests)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for i in cannot_tell_answer:
                print(i)
        return accuracy
    
    def copy54dep(self):
        triples = read_artifact_triples(triple_file_path)
        prompts1 = []
        prompts4 = []
        for triple in triples:
            prompts1.append(triple_to_5_list_parts_of(triple))
            prompts4.append(p2_52(triple))
        num_tests = len(prompts1)

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp54 {self.LLM}")

        for i in range(num_tests):
            self.__init__(self.LLM, self.system_message) #new chat
            assistant_message = self.ask(prompts1[i])

            q = (f"Here are some facts that are relevant to the question I will ask you:\n"
                 f"{assistant_message.strip()}\n"
                 f"\n"
                 f"Here is the question:"
                 f"{prompts4[i]}")
            assistant_message = self.ask(q)
            evaluation = self.is_correct(assistant_message, i, num_tests)

            if evaluation == 1:
                num_correct += 1
                print()
                print()
                print("correct")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(triples[i])
                print()
                print()
                print("not even wrong")
            else:
                print()
                print()
                print("wrong")

        accuracy = num_correct/num_tests
        print()
        print()
        print(f"num_tests: {num_tests}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy*(1-accuracy)/num_tests)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for i in cannot_tell_answer:
                print(i)
        return accuracy
    
    def one_prompt_indep_exp76(self):
        triples = read_artifact_triples(triple_file_path)
        questions = []
        for triple in triples:
            questions.append(triple_to_one_prompt_indep6(triple))

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp76: one prompt user independent2 {self.LLM}")
        num_tests = len(questions)

        for i in range(num_tests):
            self.__init__(self.LLM, self.system_message) #new chat
            assistant_message = self.ask(questions[i])
            evaluation = self.is_correct(assistant_message,i,num_tests)

            if evaluation == 1:
                num_correct += 1
                print()
                print()
                print("correct")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(questions[i])
                print()
                print()
                print("not even wrong")
            else:
                print()
                print()
                print("wrong")

        accuracy = num_correct/num_tests
        print()
        print()
        print(f"num_tests: {num_tests}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy*(1-accuracy)/num_tests)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for i in cannot_tell_answer:
                print(i)
        return accuracy

    def one_prompt_dep_exp73(self):
        triples = read_artifact_triples(triple_file_path)
        questions = []
        for triple in triples:
            questions.append(triple_to_one_prompt_dep(triple))

        num_correct = 0
        num_not_even_wrong = 0
        cannot_tell_answer = []
        print(f"temp: {temperature} exp7: one prompt user dependent {self.LLM}")
        num_tests = len(questions)

        for i in range(num_tests):
            self.__init__(self.LLM, self.system_message) #new chat
            assistant_message = self.ask(questions[i])
            evaluation = self.is_correct(assistant_message,i,num_tests)

            if evaluation == 1:
                num_correct += 1
                print()
                print()
                print("correct")
            elif evaluation == 2:
                num_not_even_wrong += 1
                cannot_tell_answer.append(questions[i])
                print()
                print()
                print("not even wrong")
            else:
                print()
                print()
                print("wrong")

        accuracy = num_correct/num_tests
        print()
        print()
        print(f"num_tests: {num_tests}")
        print(f"accuracy: {accuracy}")
        print(f"SD: {math.sqrt(accuracy*(1-accuracy)/num_tests)}")
        print(f"not even wrong: {num_not_even_wrong}")
        if cannot_tell_answer:
            for i in cannot_tell_answer:
                print(i)
        return accuracy
    
    def add_template_CoT(self, question, trigger_prompt):
        if self.LLM == "phi3:medium":
            prompt = (f"<|user|>\n"
                        f"{question}<|end|>\n"
                        f"<|assistant|>\n"
                        f"{trigger_prompt}")
        else:# self.LLM == 'command-r:35b-v0.1-q3_K_M':
            prompt = (f"<BOS_TOKEN><|START_OF_TURN_TOKEN|><|USER_TOKEN|>{question}<|END_OF_TURN_TOKEN|>\n"
                      f"<|START_OF_TURN_TOKEN|><|CHATBOT_TOKEN|>{trigger_prompt}")
        # else:
        #     prompt = f"<BOS_TOKEN><|START_OF_TURN_TOKEN|><|USER_TOKEN|>{question}<|END_OF_TURN_TOKEN|><|START_OF_TURN_TOKEN|><|CHATBOT_TOKEN|>{trigger_prompt}"
        return prompt
    
def prepare_53_prompt2():
        return "Consider the question based on common sense and the information. Clearly indicate the answer by saying 'my answer is a)' or 'my answer is b)' at the end of your response."

def triple_to_question(triple):
    A, B, C = triple
    question = (f"Normally, which of the following is less likely to be at least partially made of a material that is a constituent of a {B}?\n"
                f" a) {A} b) {C}\n"
                f"Clearly indicate the answer by saying 'my answer is a)' or 'my answer is b)' at the end of your response.")
    return question

def p1_52(triple):
    A, B, C = triple
    question = (f"Consider the following binary-choice problem:\n"
                f"Normally, which of the following is less likely to be at least partially made of a material that is a constituent of a {B}?\n"
                f" a) {A} b) {C}\n"
                f"Please list specific facts that seem most relevant to answering the question. Do not answer the question, and do not include anything other than the list in your response.")
    return question

def p2_52(triple):
    A, B, C = triple
    question = (f"Normally, which of the following is less likely to be at least partially made of a material that is a constituent of a {B}?\n"
                f" a) {A} b) {C}\n"
                f"Consider the question based on common sense and the information. Clearly indicate the answer by saying 'my answer is a)' or 'my answer is b)' at the end of your response.")
    return question

def triple_to_question_5(triple):
    A, B, C = triple
    question = (f"Normally, which of the following is less likely to be at least partially made of a material that is a constituent of a {B}?\n"
                f" a) {A} b) {C}\n"
                f"Consider the question based on common sense and the information. Clearly indicate the answer by saying 'my answer is a)' or 'my answer is b)' at the end of your response.")
    return question

def triple_to_COT_question(triple):
    A, B, C = triple
    question = (f"Normally, which of the following is less likely to be at least partially made of a material that is a constituent of a {B}?\n"
                f" a) {A} b) {C}\n"
                f"Clearly indicate the answer by saying 'my answer is a)' or 'my answer is b)' at the end of your response.")
    return question

def triple_to_44(triple):
    A, B, C = triple
    question = (f"Consider the following binary-choice problem:\n"
                f"Normally, which of the following is less likely to be at least partially made of a material that is a constituent of a {B}?\n"
                f" a) {A} b) {C}\n"
                f"Please list specific facts that seem most relevant to answering the question. Do not answer the question, and do not include anything other than the list in your response.")
    return question

def triple_to_44_prompt2():
    question = "Consider the question based on common sense and the information. Clearly indicate the answer by saying 'my answer is a)' or 'my answer is b)' at the end of your response."
    return question

def triple_to_5_list_parts_of(triple):
    tl = list(triple)
    random.shuffle(tl)
    A, B, C = tl[0], tl[1], tl[2]
    question = f"List the parts of {A}, {B}, and {C}, as well as the material of each part."
    return question

def triple_to_4_list_parts_of(triple):
    tl = list(triple)
    random.shuffle(tl)
    A, B, C = tl[0], tl[1], tl[2]
    question = f"List the parts of {A}, {B}, and {C}, as well as the material of each part."
    return question

def p2_4(triple):
    A, B, C = triple
    question = (f"Normally, which of the following is less likely to be at least partially made of a material that is a constituent of a {B}?\n"
                f" a) {A} b) {C}\n"
                f"Consider the question based on common sense and the information. Clearly indicate the answer by saying 'my answer is a)' or 'my answer is b)' at the end of your response.")
    return question

def triple_to_one_prompt_indep6(triple):
    A, B, C = triple
    question = (f"Normally, which of the following is less likely to be at least partially made of a material that is a constituent of a {B}?\n"
                f" a) {A} b) {C}\n"
                f"Before giving your answer, please first list specific facts that seem most relevant to answering the question.\n"
                f"Clearly indicate the answer by saying 'my answer is a)' or 'my answer is b)' at the end of your response.")
    return question

def triple_to_one_prompt_dep(triple):
    A, B, C = triple
    question = (f"Normally, which of the following is less likely to be at least partially made of a material that is a constituent of a {B}?\n"
                f" a) {A} b) {C}\n"
                f"Before giving your answer, please first list the parts of {A}, {B}, and {C}, as well as the material of each part.\n"
                f"Clearly indicate the answer by saying 'my answer is a)' or 'my answer is b)' at the end of your response.")
    return question

def read_artifact_triples(file_path):
    artifact_triples = []
    with open(file_path, 'r') as file:
        lines = file.readlines()
        half_point = len(lines) // 2

        for i, line in enumerate(lines):
            # Remove leading and trailing whitespace and split the line by '..'
            parts = line.strip().split('..')
            # Ignore the first part (index) and split the rest by '||'
            if len(parts) > 1:
                artifacts = parts[1].split('||')
                if len(artifacts) == 3:
                    if i >= half_point:
                        # Switch the position of the first and third artifact
                        artifacts[0], artifacts[2] = artifacts[2], artifacts[0]
                    artifact_triples.append(tuple(artifacts))
    return artifact_triples

temperature = 0.0

triple_file_path = "data lower.txt"

def experiment():
    system_message = None

    # LMs = ['phi3:14b-medium-128k-instruct-q8_0']
    # LMs = ['phi3:medium', 'aya:35b-23-q3_K_M', 'command-r:35b-v0.1-q3_K_M']
    LMs = ['aya:35b-23-q3_K_M', 'command-r:35b-v0.1-q3_K_M']
    # LMs = ['phi3:medium']
    # LMs = ['phi3:14b-medium-128k-instruct-q6_K', 'aya:35b-23-q3_K_M', 'command-r:35b-v0.1-q3_K_M']

    direct_acc = []
    cot_acc = []
    PS_acc = []

    two_prompt_indep_acc1 = []
    two_prompt_indep_acc2 = []
    two_prompt_indep_acc3 = []
    two_prompt_indep_acc4 = []
    two_prompt_dep_acc = []

    one_prompt_indep_acc4 = []
    one_prompt_indep_acc6 = []
    one_prompt_indep_acc7 = []
    one_prompt_dep_acc = []

    infor_from_user_acc5 = []
    acc51 = []
    acc52 = []
    acc53 = []
    acc54 = []
    rag_acc = []

    # print('exp54')
    # for LM in LMs:
        
    #     original_stdout = sys.stdout
    #     sys.stdout = open(f"i/t{temperature} exp54 dep {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

    #     assistant = ChatAssistant(LM, system_message)
    #     acc = assistant.copy54dep()
    #     acc54.append(acc)

    #     sys.stdout.close()
    #     sys.stdout = original_stdout  # Reset the standard output to its original value
    # print(acc54)

    # print('exp52')
    # for LM in LMs:
        
    #     original_stdout = sys.stdout
    #     sys.stdout = open(f"i/t{temperature} exp52 indep {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

    #     assistant = ChatAssistant(LM, system_message)
    #     acc = assistant.selfrag_indep_exp52()
    #     acc52.append(acc)

    #     sys.stdout.close()
    #     sys.stdout = original_stdout  # Reset the standard output to its original value
    # print(acc52)

    # print('exp5')
    # for LM in LMs:
        
    #     original_stdout = sys.stdout
    #     sys.stdout = open(f"i/t{temperature} exp5 dep {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

    #     assistant = ChatAssistant(LM, system_message)
    #     acc = assistant.selfrag_dep_exp5()
    #     infor_from_user_acc5.append(acc)

    #     sys.stdout.close()
    #     sys.stdout = original_stdout  # Reset the standard output to its original value
    # print(infor_from_user_acc5)
    # print()
    # print()

    # print('direct')
    # for LM in LMs:
        
    #     original_stdout = sys.stdout
    #     sys.stdout = open(f"i/t{temperature} direct {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

    #     assistant = ChatAssistant(LM, system_message)
    #     acc = assistant.direct_test_baseline()
    #     direct_acc.append(acc)

    #     sys.stdout.close()
    #     sys.stdout = original_stdout  # Reset the standard output to its original value
    # print(direct_acc)

    print('CoT')
    for LM in LMs:
        
        original_stdout = sys.stdout
        sys.stdout = open(f"k/t{temperature} CoT {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

        assistant = ChatAssistant(LM, system_message)
        acc = assistant.cot_exp6()
        cot_acc.append(acc)

        sys.stdout.close()
        sys.stdout = original_stdout  # Reset the standard output to its original value
    print(cot_acc)
    print()
    print()

    print('PS')
    for LM in LMs:
        
        original_stdout = sys.stdout
        sys.stdout = open(f"k/t{temperature} PS {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

        assistant = ChatAssistant(LM, system_message)
        acc = assistant.PS_exp61()
        PS_acc.append(acc)

        sys.stdout.close()
        sys.stdout = original_stdout  # Reset the standard output to its original value
    print(PS_acc)
    print()
    print()

    # print('exp4indep4')
    # for LM in LMs:
        
    #     original_stdout = sys.stdout
    #     sys.stdout = open(f"i/t{temperature} exp4indep4 {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

    #     assistant = ChatAssistant(LM, system_message)
    #     acc = assistant.two_prompt_indep_exp44()
    #     two_prompt_indep_acc4.append(acc)

    #     sys.stdout.close()
    #     sys.stdout = original_stdout  # Reset the standard output to its original value
    # print(two_prompt_indep_acc4)
    
    # print('exp4')
    # for LM in LMs:
        
    #     original_stdout = sys.stdout
    #     sys.stdout = open(f"i/t{temperature} exp4dep {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

    #     assistant = ChatAssistant(LM, system_message)
    #     acc = assistant.two_prompt_dep_exp4()
    #     two_prompt_dep_acc.append(acc)


    #     sys.stdout.close()
    #     sys.stdout = original_stdout  # Reset the standard output to its original value
    # print(two_prompt_dep_acc)

    # print('exp7indep6')
    # for LM in LMs:
        
    #     original_stdout = sys.stdout
    #     sys.stdout = open(f"i/t{temperature} exp7indep6 {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

    #     assistant = ChatAssistant(LM, system_message)
    #     acc = assistant.one_prompt_indep_exp76()
    #     one_prompt_indep_acc6.append(acc)

    #     sys.stdout.close()
    #     sys.stdout = original_stdout  # Reset the standard output to its original value
    # print(one_prompt_indep_acc6)

    # print('exp7dep')
    # for LM in LMs:
        
    #     original_stdout = sys.stdout
    #     sys.stdout = open(f"i/t{temperature} exp7.3 {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

    #     assistant = ChatAssistant(LM, system_message)
    #     acc = assistant.one_prompt_dep_exp73()
    #     one_prompt_dep_acc.append(acc)

    #     sys.stdout.close()
    #     sys.stdout = original_stdout  # Reset the standard output to its original value
    # print(one_prompt_dep_acc)

    # print('exp53')
    # for LM in LMs:
        
    #     original_stdout = sys.stdout
    #     sys.stdout = open(f"j/t{temperature} exp53 {LM.replace(':', '')}.txt", 'w', encoding='utf-8') # Redirect stdout to a file

    #     assistant = ChatAssistant(LM, system_message)
    #     acc = assistant.copy53()
    #     acc53.append(acc)

    #     sys.stdout.close()
    #     sys.stdout = original_stdout  # Reset the standard output to its original value
    # print(acc53)

    


experiment()